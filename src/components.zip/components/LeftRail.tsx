import { Flex, View } from "@adobe/react-spectrum";

function LeftRail() {
  return (
    <View backgroundColor="blue-600" gridArea="sidebar" />
  );
}

export default LeftRail;