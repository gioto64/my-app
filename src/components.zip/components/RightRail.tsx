function RightRail() {

}

export default RightRail;