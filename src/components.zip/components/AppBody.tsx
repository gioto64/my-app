
import { View } from "@adobe/react-spectrum";

function AppBody() {
  return (
    <View backgroundColor="purple-600" gridArea="content" />
  );
}

export default AppBody;