import { View } from "@adobe/react-spectrum";

function AppFooter() {
    return (
      <View backgroundColor="magenta-600" gridArea="footer" />
    );
  }
  
  export default AppFooter;