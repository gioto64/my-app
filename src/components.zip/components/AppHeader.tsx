import { View } from "@adobe/react-spectrum";

function AppHeader() {
  return (
    <View backgroundColor="celery-600" gridArea="header" />
  );
}

export default AppHeader;