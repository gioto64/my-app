import {Button, defaultTheme, Flex, Grid, Header, Provider, View} from '@adobe/react-spectrum';
import AppBody from './components/AppBody';
import AppFooter from './components/AppFooter';
import AppHeader from './components/AppHeader';
import LeftRail from './components/LeftRail';

function App() {
  return (
    <Provider theme={defaultTheme} flex = {true}>
      <Grid
        areas={[
          'header  header',
          'sidebar content',
          'footer  footer'
        ]}
        columns={['1fr', '3fr']}
        rows={['1fr', '3fr', '1fr']}
        height="size-6000"
        gap="size-100">
      <AppHeader />
      <LeftRail />
      <AppBody />
      <AppFooter />
      </Grid>
    </Provider>
  );
}

export default App;